
export interface GroundingSource {
  title: string;
  uri: string;
}

export interface Message {
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
  image?: string; // base64 image data
  sources?: GroundingSource[];
}

export interface VoiceState {
  isListening: boolean;
  isSpeaking: boolean;
  transcript: string;
}
