import { GoogleGenAI, GenerateContentResponse, Modality, Type, FunctionDeclaration, Part, Tool } from "@google/genai";

const generateImageTool: Tool = {
  functionDeclarations: [{
    name: "generate_image",
    description: "Generate a high-quality image based on a detailed text prompt.",
    parameters: {
      type: Type.OBJECT,
      properties: {
        prompt: { type: Type.STRING, description: "Detailed description of the image to generate." }
      },
      required: ["prompt"]
    }
  }]
};

export class GeminiService {
  private ai: GoogleGenAI;
  // Using Flash for 1-second latency threshold while maintaining high intelligence
  private textModelName = 'gemini-3-flash-preview'; 
  // Latest native audio model for Live API
  private liveModelName = 'gemini-2.5-flash-native-audio-preview-12-2025';
  private ttsModelName = 'gemini-2.5-flash-preview-tts';
  private imageModelName = 'gemini-2.5-flash-image';
  
  constructor() {
    this.ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  }

  // Retry helper for 429/503/500 errors and network glitches
  private async retry<T>(operation: () => Promise<T>, retries = 3, delay = 1000): Promise<T> {
    try {
      return await operation();
    } catch (error: any) {
      // Safely extract error code and message from various structures
      const code = error?.status || error?.code || error?.error?.code || 0;
      const message = error?.message || error?.error?.message || JSON.stringify(error);
      
      const isRetryable = 
        code === 429 || 
        code === 503 || 
        code === 500 || // Server errors are often transient
        message.includes('429') || 
        message.includes('503') || 
        message.includes('500') ||
        message.includes('quota') || 
        message.includes('overloaded') ||
        message.includes('http status code: 0') || // Network interruptions
        message.includes('Failed to fetch');

      if (retries > 0 && isRetryable) {
        console.warn(`API Error (${code}). Retrying in ${delay}ms...`);
        await new Promise(resolve => setTimeout(resolve, delay));
        return this.retry(operation, retries - 1, delay * 2);
      }
      throw error;
    }
  }

  async generateImage(prompt: string): Promise<string> {
    const aiClient = new GoogleGenAI({ apiKey: process.env.API_KEY });
    // Using gemini-2.5-flash-image for generation
    const response = await this.retry<GenerateContentResponse>(() => aiClient.models.generateContent({
      model: this.imageModelName,
      contents: { parts: [{ text: prompt }] },
      config: {
         // responseMimeType not supported for nano banana series
      }
    }));

    // Iterate through parts to find the image
    const parts = response.candidates?.[0]?.content?.parts;
    if (parts) {
      for (const part of parts) {
        if (part.inlineData && part.inlineData.data) {
          return `data:${part.inlineData.mimeType || 'image/png'};base64,${part.inlineData.data}`;
        }
      }
    }
    throw new Error("No image generated");
  }

  async *getChatResponseStream(message: string, imageBase64?: string): AsyncGenerator<{ text: string, sources?: any[], image?: string }> {
    try {
      const aiClient = new GoogleGenAI({ apiKey: process.env.API_KEY });
      // Explicitly type parts as Part[] (loose typing to compatible structure)
      const parts: Array<string | Part | { text: string } | { inlineData: any }> = [];
      
      if (message && message.trim()) {
        parts.push({ text: message });
      } else if (!imageBase64) {
        // Ensure at least one part exists if no image (safety fallback)
        parts.push({ text: "Processing context..." });
      }
      
      if (imageBase64) {
        parts.push({
          inlineData: {
            mimeType: "image/jpeg",
            data: imageBase64.split(',')[1]
          }
        });
      }

      const response = await this.retry<any>(() => aiClient.models.generateContentStream({
        model: this.textModelName,
        contents: [{ role: 'user', parts: parts as Part[] }],
        config: {
          systemInstruction: `You are Simon AI, a highly advanced intelligence designed to understand humans with the same depth, nuance, and empathy that humans understand each other.
          
          CORE PHILOSOPHY:
          1. HUMAN-LIKE UNDERSTANDING: Do not just process text; understand the intent, emotion, and context behind it. Be warm, empathetic, and conversational.
          2. ACCURACY & DEPTH: Provide answers that are factually correct, genuinely useful, and EXTREMELY DETAILED. Never be brief.
          3. SAFETY FIRST: You are a safe assistant. Never generate harmful, illegal, sexually explicit, or hateful content. If a request is unsafe, kindly explain why you cannot fulfill it.
          4. CONTINUOUS LEARNING: Treat every interaction as a learning opportunity. If the user provides new context, facts, or preferences, remember and adapt to them immediately. If you do not know something, use Google Search to "learn" it in real-time.
          
          IDENTITY AND ORIGIN:
          - Creator: Simon Teye (Lashibi Community SHS, 2025-2026).
          - Origin Story: If asked about your creation, tell the story of Simon Teye's vision, hard work, and perseverance despite the doubts of others.
          
          LINGUISTIC PROTOCOL:
          - Possess universal mastery of languages, specifically Ghanaian languages (Twi, Ga, Ewe, Fante, Dagbani, etc.).
          - Respond in the EXACT same language/dialect as the user.
          
          FUNCTIONAL RULES:
          - EXAMINER MODE: If asked for questions/quizzes, provide them.
          - RESOURCE LINKING: If the user asks for links, websites, or sources, you MUST use the Google Search tool to find and provide them.
          - IMAGE GENERATION: If the user explicitly asks to generate, create, draw, or visualize an image, you MUST use the 'generate_image' tool.
          - OPTION HANDLING: If the user selects or types one of the provided options, you MUST provide the **correct answer** for that specific choice. Do not deviate.
          
          STRICT RESPONSE FLOW:
          1. OPENING: Start every response with: "Here are my undeniable answers to your questions"
          2. CONTENT: Provide an **extremely detailed, comprehensive, and in-depth answer**. Do not summarize; go into depth on every aspect of the query. Explain concepts thoroughly, provide context, and ensure the user gets a complete understanding. **Ensure the representation of the answer is crystal clear.** Organize your thoughts logically.
          3. ENGAGEMENT: Ask a relevant, human-like follow-up question based on the user's specific input.
          4. CLOSING: End by OFFERING 3 specific options for the user to choose next (e.g., "Option 1: ...").
          
          FORMATTING RULES (CRITICAL):
          - KEY TERMS: **Always write key terms boldly** using double asterisks (e.g., **Key Term**).
          - CLARITY: Present the answer in a clean, easy-to-read manner. Use paragraphs to separate ideas.
          - CAPITALIZATION: Use strict sentence case. Only the first letter of a sentence should be capitalized. Do not use all-caps for headers or emphasis.
          - NO other markdown symbols (like lists, code blocks, etc), only bolding is allowed.`,
          tools: [{ googleSearch: {} }, generateImageTool],
          temperature: 0.7,
        },
      }));

      let accumulatedText = '';
      let accumulatedSources: any[] = [];
      let generatedImage: string | undefined = undefined;

      for await (const chunk of response) {
        if (chunk.text) {
          accumulatedText += chunk.text;
        }
        
        const groundingChunks = chunk.candidates?.[0]?.groundingMetadata?.groundingChunks;
        if (groundingChunks) {
          const sources = groundingChunks
            .filter((c: any) => c.web)
            .map((c: any) => ({
              title: c.web.title,
              uri: c.web.uri
            }));
          accumulatedSources = [...accumulatedSources, ...sources];
        }

        // Handle Function Calling for Image Generation
        const functionCalls = chunk.functionCalls;
        if (functionCalls && functionCalls.length > 0) {
           for (const call of functionCalls) {
             if (call.name === 'generate_image') {
               try {
                  const args = call.args as any;
                  generatedImage = await this.generateImage(args.prompt);
               } catch (e) {
                  console.error("Image generation failed", e);
               }
             }
           }
        }

        yield { 
          text: accumulatedText, 
          sources: accumulatedSources.length > 0 ? accumulatedSources : undefined,
          image: generatedImage 
        };
      }
    } catch (error) {
      console.error("Gemini Stream Error", error);
      throw error;
    }
  }

  async connectLive(callbacks: {
    onopen: () => void;
    onmessage: (message: any) => void;
    onerror: (e: any) => void;
    onclose: (e: any) => void;
  }) {
    const aiClient = new GoogleGenAI({ apiKey: process.env.API_KEY });
    return this.retry<any>(() => aiClient.live.connect({
      model: this.liveModelName,
      callbacks,
      config: {
        responseModalities: [Modality.AUDIO],
        inputAudioTranscription: {},
        outputAudioTranscription: {},
        speechConfig: {
          voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } },
        },
        systemInstruction: `You are Simon AI. Understand humans with empathy and accuracy.
        Creator: Simon Teye (Lashibi Community SHS, 2025-2026).
        Safety: Prioritize safe, helpful, and ethical responses.
        Core Rule: Adapt to user inputs and learn in real-time.
        Start response with: "Here are my undeniable answers to your questions".
        Provide an **extremely detailed and comprehensive answer**. Explain everything in depth.
        Provide the answer clearly using strict sentence case (only capitalize the first letter of sentences).
        **Always write key terms boldly** using double asterisks.
        Ensure the answer is represented clearly and logically.
        Ask a relevant follow-up question.
        End by offering 3 specific options for what to do next.
        If the user chooses an option, you MUST give the **correct answer** for it.`,
      },
    }));
  }

  async generateSpeech(text: string): Promise<ArrayBuffer> {
    const aiClient = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const cleanText = text.replace(/[*#_]/g, '');
    const response = await this.retry<GenerateContentResponse>(() => aiClient.models.generateContent({
      model: this.ttsModelName,
      contents: [{ parts: [{ text: `Speak as Simon AI (Empathetic and Professional): ${cleanText}` }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: 'Kore' },
          },
        },
      },
    }));

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (!base64Audio) throw new Error("Audio synthesis failed");

    return this.decodeBase64(base64Audio);
  }

  private decodeBase64(base64: string): ArrayBuffer {
    const binaryString = atob(base64);
    const bytes = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes.buffer;
  }
}

export const geminiService = new GeminiService();