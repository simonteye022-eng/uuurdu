import React, { useState, useEffect, useRef } from 'react';
import { Message } from './types';
import { geminiService } from './services/geminiService';
import Header from './components/Header';
import ChatInterface from './components/ChatInterface';
import VoiceControls from './components/VoiceControls';
import Sidebar from './components/Sidebar';

interface ChatSession {
  id: string;
  title: string;
  messages: Message[];
  timestamp: number;
}

const WELCOME_CONTENT = 'I am Simon AI Intelligence, your universal neural architect. I was built by Simon Teye (2025-2026), a visionary student of Lashibi Community SHS. How can I assist you today?';

const App: React.FC = () => {
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [currentSessionId, setCurrentSessionId] = useState<string>('');
  const [isListening, setIsListening] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [liveTranscript, setLiveTranscript] = useState({ user: '', ai: '' });
  
  // Theme States
  const [isDarkMode, setIsDarkMode] = useState(() => {
    return localStorage.getItem('simon_ai_theme') === 'dark';
  });
  const [mood, setMood] = useState(() => {
    return localStorage.getItem('simon_ai_mood') || 'mood-neural';
  });

  const sessionPromiseRef = useRef<Promise<any> | null>(null);
  const isConnectingRef = useRef(false);
  const audioContextRef = useRef<AudioContext | null>(null);
  const outputAudioContextRef = useRef<AudioContext | null>(null);
  const nextStartTimeRef = useRef<number>(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  const transcriptBufferRef = useRef({ user: '', ai: '' });

  useEffect(() => {
    const saved = localStorage.getItem('simon_ai_v2_history');
    if (saved) {
      const parsed = JSON.parse(saved);
      setSessions(parsed);
      if (parsed.length > 0) setCurrentSessionId(parsed[0].id);
      else createNewChat();
    } else {
      createNewChat();
    }
  }, []);

  useEffect(() => {
    if (sessions.length > 0) {
      localStorage.setItem('simon_ai_v2_history', JSON.stringify(sessions));
    }
  }, [sessions]);

  // Handle Dark Mode
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('simon_ai_theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('simon_ai_theme', 'light');
    }
  }, [isDarkMode]);

  // Handle Mood Mode
  useEffect(() => {
    // Remove existing mood classes
    document.body.classList.remove(
      'mood-neural', 'mood-ocean', 'mood-nebula', 'mood-solar', 'mood-crimson',
      'mood-cyber', 'mood-neon', 'mood-forest'
    );
    // Add new mood class if not default (neural doesn't need a class as it's default variable set, but adding it for consistency)
    if (mood !== 'mood-neural') {
      document.body.classList.add(mood);
    }
    localStorage.setItem('simon_ai_mood', mood);
  }, [mood]);

  const toggleDarkMode = () => setIsDarkMode(!isDarkMode);

  const createNewChat = () => {
    const newId = Date.now().toString();
    const newSession: ChatSession = {
      id: newId,
      title: 'Initial Neural Link',
      messages: [{
        role: 'assistant',
        content: WELCOME_CONTENT,
        timestamp: Date.now()
      }],
      timestamp: Date.now()
    };
    setSessions(prev => [newSession, ...prev]);
    setCurrentSessionId(newId);
    setIsSidebarOpen(false);
  };

  const clearAllHistory = () => {
    if (window.confirm("Permanently erase all neural thread history?")) {
      setSessions([]);
      localStorage.removeItem('simon_ai_v2_history');
      createNewChat();
    }
  };

  const currentSession = sessions.find(s => s.id === currentSessionId) || sessions[0];

  const updateCurrentSession = (updatedMessages: Message[]) => {
    setSessions(prev => prev.map(s => {
      if (s.id === currentSessionId) {
        let newTitle = s.title;
        const firstUserMsg = updatedMessages.find(m => m.role === 'user');
        if (s.title === 'Initial Neural Link' && firstUserMsg) {
          newTitle = firstUserMsg.content.slice(0, 40) + (firstUserMsg.content.length > 40 ? '...' : '');
        }
        return { ...s, messages: updatedMessages, title: newTitle };
      }
      return s;
    }));
  };

  const deleteSession = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const updated = sessions.filter(s => s.id !== id);
    setSessions(updated);
    if (currentSessionId === id) {
      if (updated.length > 0) setCurrentSessionId(updated[0].id);
      else createNewChat();
    }
  };

  const encode = (bytes: Uint8Array) => {
    let binary = '';
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) binary += String.fromCharCode(bytes[i]);
    return btoa(binary);
  };

  const decode = (base64: string) => {
    const binaryString = atob(base64);
    const bytes = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) bytes[i] = binaryString.charCodeAt(i);
    return bytes;
  };

  async function decodeAudioData(data: Uint8Array, ctx: AudioContext): Promise<AudioBuffer> {
    const dataInt16 = new Int16Array(data.buffer);
    const buffer = ctx.createBuffer(1, dataInt16.length, 24000);
    const channelData = buffer.getChannelData(0);
    for (let i = 0; i < dataInt16.length; i++) {
      channelData[i] = dataInt16[i] / 32768.0;
    }
    return buffer;
  }

  const stopAudio = () => {
    for (const source of sourcesRef.current) {
      try { source.stop(); } catch (e) {}
    }
    sourcesRef.current.clear();
    nextStartTimeRef.current = 0;
    setIsSpeaking(false);
  };

  const startLiveSession = async () => {
    if (isConnectingRef.current) return;
    try {
      isConnectingRef.current = true;
      stopAudio();
      setIsListening(true);
      setLiveTranscript({ user: '', ai: '' });
      transcriptBufferRef.current = { user: '', ai: '' };

      if (!audioContextRef.current) {
        audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      }
      if (!outputAudioContextRef.current) {
        outputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      }

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      
      sessionPromiseRef.current = geminiService.connectLive({
        onopen: () => {
          isConnectingRef.current = false;
          const source = audioContextRef.current!.createMediaStreamSource(stream);
          const processor = audioContextRef.current!.createScriptProcessor(4096, 1, 1);
          processor.onaudioprocess = (e) => {
            const inputData = e.inputBuffer.getChannelData(0);
            const int16 = new Int16Array(inputData.length);
            for (let i = 0; i < inputData.length; i++) int16[i] = inputData[i] * 32768;
            sessionPromiseRef.current?.then((session: any) => {
              session.sendRealtimeInput({
                media: { data: encode(new Uint8Array(int16.buffer)), mimeType: 'audio/pcm;rate=16000' },
              });
            });
          };
          source.connect(processor);
          processor.connect(audioContextRef.current!.destination);
          (window as any)._liveResources = { stream, processor, source };
        },
        onmessage: async (message: any) => {
          const base64Audio = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
          if (base64Audio) {
            setIsSpeaking(true);
            const ctx = outputAudioContextRef.current!;
            nextStartTimeRef.current = Math.max(nextStartTimeRef.current, ctx.currentTime);
            const audioBuffer = await decodeAudioData(decode(base64Audio), ctx);
            const source = ctx.createBufferSource();
            source.buffer = audioBuffer;
            source.connect(ctx.destination);
            source.onended = () => {
              sourcesRef.current.delete(source);
              if (sourcesRef.current.size === 0) setIsSpeaking(false);
            };
            source.start(nextStartTimeRef.current);
            nextStartTimeRef.current += audioBuffer.duration;
            sourcesRef.current.add(source);
          }

          if (message.serverContent?.inputTranscription) {
            transcriptBufferRef.current.user += message.serverContent.inputTranscription.text;
            setLiveTranscript(prev => ({ ...prev, user: transcriptBufferRef.current.user }));
          }
          if (message.serverContent?.outputTranscription) {
            transcriptBufferRef.current.ai += message.serverContent.outputTranscription.text;
            setLiveTranscript(prev => ({ ...prev, ai: transcriptBufferRef.current.ai }));
          }

          if (message.serverContent?.turnComplete) {
            const userText = transcriptBufferRef.current.user.trim();
            const aiText = transcriptBufferRef.current.ai.trim();
            
            if (userText || aiText) {
              const userMsg: Message = { role: 'user', content: userText || "[Neural Audio Input]", timestamp: Date.now() };
              const aiMsg: Message = { role: 'assistant', content: aiText || "[Neural Synthesis]", timestamp: Date.now() };
              updateCurrentSession([...currentSession.messages, userMsg, aiMsg]);
            }
            
            transcriptBufferRef.current = { user: '', ai: '' };
            setLiveTranscript({ user: '', ai: '' });
          }

          if (message.serverContent?.interrupted) stopAudio();
        },
        onerror: (e: any) => { 
          console.error("Live Session Error:", e);
          isConnectingRef.current = false;
          setError("Neural link desynced.");
          setIsListening(false); 
        },
        onclose: () => {
          isConnectingRef.current = false;
          setIsListening(false);
        },
      });
    } catch (err) {
      isConnectingRef.current = false;
      setError("Microphone required for Live Link.");
      setIsListening(false);
    }
  };

  const stopLiveSession = () => {
    const resources = (window as any)._liveResources;
    if (resources) {
      if (resources.stream) resources.stream.getTracks().forEach((t: any) => t.stop());
      if (resources.processor) resources.processor.disconnect();
      if (resources.source) resources.source.disconnect();
      delete (window as any)._liveResources;
    }
    sessionPromiseRef.current?.then((s: any) => s.close());
    sessionPromiseRef.current = null;
    setIsListening(false);
    isConnectingRef.current = false;
    setLiveTranscript({ user: '', ai: '' });
  };

  const handleSendMessage = async (text: string) => {
    if (!text.trim() && !selectedImage) return;
    stopAudio();
    const userMessage: Message = { 
      role: 'user', 
      content: text || "Process context", 
      timestamp: Date.now(),
      image: selectedImage || undefined
    };
    
    // Optimistically update UI with user message
    const updatedMessages = [...(currentSession?.messages || []), userMessage];
    updateCurrentSession(updatedMessages);
    
    const currentImageInput = selectedImage;
    setSelectedImage(null);
    setIsProcessing(true);
    setError(null);
    
    try {
      const stream = geminiService.getChatResponseStream(text, currentImageInput || undefined);
      let assistantMessageAdded = false;

      for await (const chunk of stream) {
        const msgContent = { 
            role: 'assistant' as const, 
            content: chunk.text, 
            timestamp: Date.now(), 
            sources: chunk.sources,
            image: chunk.image // Handle generated image
        };

        if (!assistantMessageAdded) {
          assistantMessageAdded = true;
          updateCurrentSession([...updatedMessages, msgContent]);
        } else {
          // Update existing assistant message
          updateCurrentSession([...updatedMessages, msgContent]);
        }
      }
    } catch (err: any) {
      console.error(err);
      // Attempt to extract message from various error structures
      const code = err?.status || err?.code || err?.error?.code;
      const msg = err?.message || err?.error?.message || JSON.stringify(err);
      
      if (msg.includes('429') || msg.includes('quota') || msg.includes('RESOURCE_EXHAUSTED')) {
        setError("System Overload: Neural quota exceeded. Please try again later.");
      } else if (msg.includes('500') || msg.includes('503') || msg.includes('http status code: 0') || code === 500) {
        setError("Network Instability: Upstream service error. Please retry.");
      } else {
        setError("Neural synthesis interrupted.");
      }
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="flex h-screen w-full bg-[#fdfdfc] dark:bg-stone-950 overflow-hidden font-sans selection:bg-lime-100 dark:selection:bg-lime-900/30 transition-colors duration-300">
      <Sidebar 
        sessions={sessions} 
        activeId={currentSessionId} 
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
        onSelect={(id) => { setCurrentSessionId(id); setIsSidebarOpen(false); }}
        onNewChat={createNewChat}
        onDelete={deleteSession}
        onClearAll={clearAllHistory}
      />

      <div className="flex-1 flex flex-col min-w-0 bg-white dark:bg-stone-900 shadow-2xl relative z-10 transition-all duration-500">
        <Header 
          onOpenSidebar={() => setIsSidebarOpen(true)} 
          onNewChat={createNewChat} 
          isDarkMode={isDarkMode}
          onToggleDarkMode={toggleDarkMode}
          currentMood={mood}
          onMoodChange={setMood}
        />
        
        <main className="flex-1 overflow-y-auto px-4 md:px-12 py-10 custom-scrollbar bg-[radial-gradient(circle_at_top_right,rgba(var(--color-400),0.05),transparent_60%)] dark:bg-[radial-gradient(circle_at_top_right,rgba(var(--color-400),0.02),transparent_60%)]">
          <ChatInterface 
            messages={currentSession?.messages || []} 
            isProcessing={isProcessing} 
            error={error}
          />
        </main>

        <footer className="px-6 md:px-12 py-8 bg-white/90 dark:bg-stone-900/90 backdrop-blur-3xl border-t border-stone-100 dark:border-stone-800">
          <div className="max-w-4xl mx-auto">
            {selectedImage && (
              <div className="flex items-center gap-4 bg-lime-50/50 dark:bg-lime-900/10 border border-lime-200/50 dark:border-lime-700/30 p-2 rounded-[32px] mb-4 animate-in slide-in-from-bottom-4 shadow-sm">
                <div className="relative group">
                  <img src={selectedImage} alt="Neural Preview" className="w-16 h-16 object-cover rounded-2xl shadow-xl transition-transform group-hover:scale-110" />
                  <button onClick={() => setSelectedImage(null)} className="absolute -top-2 -right-2 bg-stone-900 dark:bg-stone-100 text-white dark:text-stone-900 rounded-full p-1 hover:bg-red-600 dark:hover:bg-red-500 transition-colors shadow-lg">
                    <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M6 18L18 6M6 6l12 12" /></svg>
                  </button>
                </div>
                <div className="flex flex-col">
                  <span className="text-[10px] font-black text-lime-700 dark:text-lime-400 uppercase tracking-widest">Vision Context Linked</span>
                  <span className="text-[9px] text-stone-400 dark:text-stone-500 font-bold uppercase">Ready for Analysis</span>
                </div>
              </div>
            )}
            
            <VoiceControls 
              onSend={handleSendMessage}
              onImageSelect={setSelectedImage}
              isListening={isListening}
              isSpeaking={isSpeaking}
              isProcessing={isProcessing}
              liveTranscript={liveTranscript}
              onToggleListen={() => isListening ? stopLiveSession() : startLiveSession()}
              onStopSpeak={stopAudio}
            />
          </div>
        </footer>
      </div>
    </div>
  );
};

export default App;