
import React, { useEffect, useRef, useState } from 'react';
import { Message } from '../types.ts';

interface ChatInterfaceProps {
  messages: Message[];
  isProcessing: boolean;
  error: string | null;
}

const ChatInterface: React.FC<ChatInterfaceProps> = ({ messages, isProcessing, error }) => {
  const endRef = useRef<HTMLDivElement>(null);
  const [progress, setProgress] = useState(0);

  const WELCOME_TEXT = "I am Simon AI Intelligence, your universal neural architect. I was built by Simon Teye (2025-2026), a visionary student of Lashibi Community SHS. How can I assist you today?";

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isProcessing]);

  useEffect(() => {
    let interval: number;
    if (isProcessing) {
      setProgress(0);
      interval = window.setInterval(() => {
        setProgress(prev => (prev < 95 ? prev + 1 : prev));
      }, 100); 
    } else {
      setProgress(100);
    }
    return () => clearInterval(interval);
  }, [isProcessing]);

  // Helper function to parse bold text marked with **
  const renderMessageContent = (text: string) => {
    // Split by the bold markdown syntax **text**
    const parts = text.split(/(\*\*[^*]+\*\*)/g);
    return parts.map((part, index) => {
      if (part.startsWith('**') && part.endsWith('**')) {
        // Render bold content without asterisks
        return (
          <strong key={index} className="font-black text-stone-900 dark:text-white">
            {part.slice(2, -2)}
          </strong>
        );
      }
      return <span key={index}>{part}</span>;
    });
  };

  // Only show processing indicator if the last message is from user (waiting for AI)
  const lastMessage = messages[messages.length - 1];
  const showProcessingIndicator = isProcessing && (!lastMessage || lastMessage.role === 'user');

  return (
    <div className="space-y-12">
      {messages.map((msg, idx) => {
        const isWelcome = msg.content === WELCOME_TEXT;
        
        return (
          <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} animate-in fade-in slide-in-from-bottom-4 duration-500`}>
            <div className={`flex flex-col gap-3 max-w-[95%] md:max-w-[85%]`}>
              
              <div className={`px-10 py-8 shadow-[0_15px_40px_-10px_rgba(0,0,0,0.05)] border tracking-wide leading-relaxed transition-colors ${
                msg.role === 'user' 
                  ? 'bg-stone-900 dark:bg-stone-100 text-white dark:text-stone-900 border-transparent message-user' 
                  : 'bg-white dark:bg-stone-800 text-stone-800 dark:text-stone-100 border-stone-100 dark:border-stone-700 message-ai'
              }`}>
                <div className={`text-[16px] font-medium whitespace-pre-wrap selection:bg-lime-100 dark:selection:bg-lime-900/40 ${
                  isWelcome ? 'text-lime-600 dark:text-lime-400 font-bold italic' : ''
                }`}>
                  {isWelcome ? msg.content : renderMessageContent(msg.content)}
                </div>
                
                {msg.sources && msg.sources.length > 0 && (
                  <div className="mt-8 pt-6 border-t border-stone-100 dark:border-stone-700 space-y-4">
                    <p className="text-[10px] font-black text-stone-400 dark:text-stone-500 uppercase tracking-widest">Global Grounding Data</p>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {msg.sources.map((source, sIdx) => (
                        <a 
                          key={sIdx}
                          href={source.uri} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="flex items-center gap-3 p-3 bg-stone-50 dark:bg-stone-900 hover:bg-lime-50 dark:hover:bg-lime-900/20 border border-stone-100 dark:border-stone-800 rounded-2xl transition-all group"
                        >
                          <span className="text-sm">🔗</span>
                          <span className="text-xs font-bold text-stone-800 dark:text-stone-200 truncate group-hover:text-lime-700 dark:group-hover:text-lime-400">{source.title}</span>
                        </a>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {msg.image && (
                <div className={`relative group ${msg.role === 'user' ? 'self-end' : 'self-start mt-2'}`}>
                  <div className="absolute inset-0 bg-lime-500/10 rounded-[40px] transform rotate-1"></div>
                  <img 
                    src={msg.image} 
                    alt={msg.role === 'user' ? "Input Context" : "Generated Visual"} 
                    className="relative w-80 md:w-96 rounded-[40px] shadow-2xl border-4 border-white dark:border-stone-800 ring-1 ring-stone-100 dark:ring-stone-700 object-cover" 
                  />
                  {msg.role === 'assistant' && (
                    <div className="absolute bottom-4 right-4 bg-white/90 dark:bg-stone-900/90 backdrop-blur-sm px-3 py-1.5 rounded-full border border-stone-200 dark:border-stone-700 shadow-sm">
                      <span className="text-[8px] font-black uppercase tracking-widest text-lime-600 dark:text-lime-400">AI Generated</span>
                    </div>
                  )}
                </div>
              )}
              
              <div className={`flex items-center gap-2 px-5 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                 <span className="text-[9px] font-bold text-stone-300 dark:text-stone-600 uppercase tracking-widest italic">
                   {msg.role === 'assistant' ? 'Neural Synthesis Engine' : 'Analytical Query'}
                 </span>
              </div>
            </div>
          </div>
        );
      })}
      
      {showProcessingIndicator && (
        <div className="flex flex-col items-start gap-4">
          <div className="bg-white dark:bg-stone-800 px-10 py-8 rounded-[45px] rounded-tl-none border border-lime-200 dark:border-lime-900 shadow-2xl flex flex-col gap-6 min-w-[320px] transition-colors">
            <div className="flex gap-5 items-center">
              <div className="w-10 h-10 bg-stone-900 dark:bg-stone-100 rounded-2xl flex items-center justify-center relative">
                <div className="absolute inset-0 bg-lime-500 rounded-2xl animate-ping opacity-20"></div>
                <svg className="w-6 h-6 text-lime-400 dark:text-lime-600 animate-pulse" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
              </div>
              <div className="flex flex-col">
                <span className="text-[10px] font-black text-stone-400 dark:text-stone-500 uppercase tracking-widest">Sub-Second Processing</span>
                <span className="text-sm font-bold text-stone-800 dark:text-stone-100">Synthesizing Detailed Answer...</span>
              </div>
            </div>
            <div className="w-full h-1.5 bg-stone-50 dark:bg-stone-900 rounded-full overflow-hidden">
               <div className="h-full bg-gradient-to-r from-lime-500 to-yellow-400 transition-all duration-300" style={{ width: `${progress}%` }}></div>
            </div>
          </div>
        </div>
      )}

      {error && (
        <div className="bg-red-50 dark:bg-red-900/10 border border-red-200 dark:border-red-800 text-red-700 dark:text-red-400 py-4 px-8 rounded-[30px] flex items-center gap-4 max-w-md mx-auto shadow-sm animate-shake">
          <p className="text-xs font-bold uppercase tracking-widest">{error}</p>
        </div>
      )}
      
      <div ref={endRef} />
    </div>
  );
};

export default ChatInterface;
