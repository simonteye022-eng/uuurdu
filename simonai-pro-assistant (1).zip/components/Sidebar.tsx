
import React, { useState, useMemo } from 'react';

interface ChatSession {
  id: string;
  title: string;
  timestamp: number;
}

interface SidebarProps {
  sessions: ChatSession[];
  activeId: string;
  isOpen: boolean;
  onClose: () => void;
  onSelect: (id: string) => void;
  onNewChat: () => void;
  onDelete: (id: string, e: React.MouseEvent) => void;
  onClearAll: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ 
  sessions, 
  activeId, 
  isOpen, 
  onClose, 
  onSelect, 
  onNewChat,
  onDelete,
  onClearAll
}) => {
  const [searchQuery, setSearchQuery] = useState('');

  const groupedSessions = useMemo(() => {
    const filtered = sessions.filter(s => 
      s.title.toLowerCase().includes(searchQuery.toLowerCase())
    );

    const groups: { [key: string]: ChatSession[] } = {
      'Today': [],
      'This Week': [],
      'Older': []
    };

    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
    const oneWeekAgo = today - 7 * 24 * 60 * 60 * 1000;

    filtered.forEach(session => {
      if (session.timestamp >= today) {
        groups['Today'].push(session);
      } else if (session.timestamp >= oneWeekAgo) {
        groups['This Week'].push(session);
      } else {
        groups['Older'].push(session);
      }
    });

    return groups;
  }, [sessions, searchQuery]);

  const hasResults = (Object.values(groupedSessions) as ChatSession[][]).some(group => group.length > 0);

  return (
    <>
      {isOpen && (
        <div 
          className="fixed inset-0 bg-stone-900/60 dark:bg-stone-950/80 backdrop-blur-md z-40 lg:hidden"
          onClick={onClose}
        />
      )}

      <aside className={`fixed lg:static inset-y-0 left-0 w-80 bg-stone-50 dark:bg-stone-950 border-r border-stone-200 dark:border-stone-800 z-50 transform transition-all duration-500 ease-[cubic-bezier(0.4,0,0.2,1)] flex flex-col ${
        isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
      }`}>
        {/* Creator's Tribute Section */}
        <div className="p-6 bg-stone-900 dark:bg-stone-900 text-white border-b border-stone-800 dark:border-stone-800">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-8 h-8 bg-lime-500 rounded-lg flex items-center justify-center font-black text-stone-900 text-xs shadow-[0_0_15px_rgba(163,230,53,0.4)]">S</div>
            <div>
              <p className="text-[10px] font-black uppercase tracking-widest text-lime-400">Project Founder</p>
              <h3 className="text-sm font-bold truncate">Simon Teye</h3>
            </div>
          </div>
          <div className="bg-white/5 rounded-2xl p-4 border border-white/10 group cursor-default">
            <p className="text-[9px] leading-relaxed text-stone-300 font-medium italic">
              "Building the future at <span className="text-lime-400 font-bold">Lashibi SHS</span>. From doubts in 2025 to intelligence in 2026."
            </p>
            <div className="mt-3 flex items-center gap-2">
               <span className="text-[8px] px-2 py-0.5 bg-stone-800 rounded-full text-stone-400 font-bold uppercase">Dev Journey</span>
               <div className="h-1 flex-1 bg-stone-800 rounded-full overflow-hidden">
                  <div className="h-full bg-lime-500 w-full animate-pulse"></div>
               </div>
            </div>
          </div>
        </div>

        <div className="p-6 border-b border-stone-200 dark:border-stone-800 bg-white dark:bg-stone-950 transition-colors space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-black text-stone-900 dark:text-stone-100 uppercase tracking-[0.2em]">Threads</h2>
            <button 
              onClick={onNewChat}
              className="p-2.5 bg-stone-900 dark:bg-stone-100 text-white dark:text-stone-900 rounded-xl hover:bg-black dark:hover:bg-white transition-all shadow-xl active:scale-95"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 4v16m8-8H4" />
              </svg>
            </button>
          </div>
          
          <div className="relative group">
            <input 
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Filter memory..."
              className="w-full pl-10 pr-4 py-3 bg-stone-100 dark:bg-stone-900 border-transparent focus:bg-white dark:focus:bg-stone-800 focus:border-lime-500/30 dark:text-stone-100 rounded-2xl text-xs font-medium outline-none transition-all shadow-inner"
            />
            <svg className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400 dark:text-stone-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto custom-scrollbar p-4 space-y-6 bg-transparent">
          {hasResults ? (
            (Object.entries(groupedSessions) as [string, ChatSession[]][]).map(([groupName, items]) => (
              items.length > 0 && (
                <div key={groupName} className="space-y-2">
                  <h3 className="px-4 text-[10px] font-black text-stone-400 dark:text-stone-600 uppercase tracking-widest">{groupName}</h3>
                  <div className="space-y-1">
                    {items.map((session) => (
                      <div 
                        key={session.id}
                        onClick={() => onSelect(session.id)}
                        className={`group flex items-center justify-between p-4 rounded-2xl cursor-pointer transition-all border ${
                          activeId === session.id 
                            ? 'bg-white dark:bg-stone-900 border-lime-200 dark:border-lime-900 shadow-md ring-1 ring-lime-500/10 dark:ring-lime-400/5' 
                            : 'bg-transparent border-transparent hover:bg-stone-100 dark:hover:bg-stone-900/50 hover:border-stone-200 dark:hover:border-stone-800'
                        }`}
                      >
                        <div className="flex items-center gap-4 min-w-0">
                          <div className={`w-1.5 h-1.5 rounded-full flex-shrink-0 ${
                            activeId === session.id ? 'bg-lime-500 shadow-[0_0_8px_#84cc16]' : 'bg-stone-300 dark:bg-stone-700'
                          }`}></div>
                          <p className={`text-sm font-bold truncate ${
                            activeId === session.id ? 'text-stone-900 dark:text-stone-100' : 'text-stone-500 dark:text-stone-500'
                          }`}>
                            {session.title}
                          </p>
                        </div>
                        <button 
                          onClick={(e) => onDelete(session.id, e)}
                          className="opacity-0 group-hover:opacity-100 p-2 text-stone-400 dark:text-stone-600 hover:text-red-600 dark:hover:text-red-400 transition-all rounded-lg"
                        >
                          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )
            ))
          ) : (
            <div className="py-20 text-center flex flex-col items-center gap-4 opacity-40">
              <svg className="w-12 h-12 text-stone-300 dark:text-stone-800" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0" />
              </svg>
              <p className="text-xs font-bold text-stone-400 dark:text-stone-700 uppercase tracking-widest">Neural Void</p>
            </div>
          )}
        </div>

        <div className="p-6 border-t border-stone-200 dark:border-stone-800 bg-white dark:bg-stone-950 transition-colors space-y-4">
          {sessions.length > 0 && (
            <button 
              onClick={onClearAll}
              className="w-full py-3 px-4 flex items-center justify-center gap-2 text-[10px] font-black uppercase tracking-widest text-red-500 hover:text-red-600 dark:text-red-400 dark:hover:text-red-300 hover:bg-red-50 dark:hover:bg-red-900/10 rounded-xl transition-all"
            >
              Reset All Neural Threads
            </button>
          )}
          
          <div className="flex items-center gap-4 bg-stone-50 dark:bg-stone-900 p-3 rounded-2xl border border-stone-100 dark:border-stone-800 transition-colors">
            <div className="w-8 h-8 bg-stone-900 dark:bg-stone-100 rounded-xl flex items-center justify-center relative">
              <span className="text-lime-400 dark:text-lime-600 text-[10px] font-black">AI</span>
            </div>
            <div>
              <p className="text-[10px] font-black text-stone-900 dark:text-stone-100 uppercase leading-none">Flash Engine 4.0</p>
              <p className="text-[8px] text-stone-400 dark:text-stone-500 font-bold uppercase tracking-widest mt-1">Encrypted Session</p>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
};

export default Sidebar;
