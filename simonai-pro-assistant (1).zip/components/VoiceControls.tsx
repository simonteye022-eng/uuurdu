
import React, { useState, useRef } from 'react';

interface VoiceControlsProps {
  onSend: (text: string) => void;
  onImageSelect: (base64: string) => void;
  isListening: boolean;
  isSpeaking: boolean;
  isProcessing: boolean;
  liveTranscript?: { user: string; ai: string };
  onToggleListen: () => void;
  onStopSpeak: () => void;
}

const VoiceControls: React.FC<VoiceControlsProps> = ({ 
  onSend, 
  onImageSelect,
  isListening, 
  isSpeaking, 
  isProcessing,
  liveTranscript,
  onToggleListen,
  onStopSpeak
}) => {
  const [text, setText] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => onImageSelect(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (text.trim()) {
      onSend(text);
      setText('');
    }
  };

  return (
    <div className="w-full relative">
      {/* Real-time Transcription Display */}
      {isListening && (
        <div className="flex flex-col items-center justify-center gap-8 py-10 animate-in zoom-in duration-500">
          
          <div className="w-full max-w-lg space-y-4 px-4">
            {(liveTranscript?.user || liveTranscript?.ai) ? (
              <>
                {liveTranscript.user && (
                  <div className="flex justify-end animate-in fade-in slide-in-from-right-4">
                    <div className="bg-stone-900 dark:bg-stone-100 text-white dark:text-stone-900 px-5 py-3 rounded-2xl rounded-tr-none text-xs font-medium shadow-xl max-w-[80%]">
                      {liveTranscript.user}
                    </div>
                  </div>
                )}
                {liveTranscript.ai && (
                  <div className="flex justify-start animate-in fade-in slide-in-from-left-4">
                    <div className="bg-white dark:bg-stone-800 border border-stone-100 dark:border-stone-700 text-stone-800 dark:text-stone-100 px-5 py-3 rounded-2xl rounded-tl-none text-xs font-bold shadow-xl max-w-[80%] italic">
                      {liveTranscript.ai}
                    </div>
                  </div>
                )}
              </>
            ) : (
              <div className="text-center">
                <p className="text-[10px] font-black text-stone-300 dark:text-stone-600 uppercase tracking-[0.3em] animate-pulse">Waiting for your voice...</p>
              </div>
            )}
          </div>

          <div className="relative w-40 h-40 flex items-center justify-center">
             <div className="absolute inset-0 bg-lime-500/10 dark:bg-lime-400/5 rounded-full ripple-ring"></div>
             <div className="absolute inset-0 bg-yellow-400/10 dark:bg-yellow-400/5 rounded-full ripple-ring [animation-delay:1s]"></div>
             
             <div className="absolute inset-4 border border-lime-500/20 dark:border-lime-500/10 rounded-full animate-orb">
               <div className="absolute -top-1 left-1/2 -translate-x-1/2 w-2 h-2 bg-lime-500 rounded-full shadow-[0_0_10px_#84cc16]"></div>
             </div>

             <div className="w-20 h-20 bg-stone-900 dark:bg-stone-100 rounded-[35px] fluid-shape flex items-center justify-center shadow-2xl z-10 overflow-hidden relative transition-colors">
                <div className="absolute inset-0 bg-gradient-to-tr from-lime-600/20 dark:from-lime-400/10 to-transparent"></div>
                <div className="flex gap-1.5 h-8 items-center justify-center z-20">
                   {[...Array(5)].map((_, i) => (
                     <div 
                       key={i} 
                       className="w-1 bg-lime-400 dark:bg-lime-600 rounded-full transition-all duration-75" 
                       style={{ 
                         height: `${40 + Math.random() * 60}%`,
                         animation: `pulse 0.6s ease-in-out infinite alternate ${i * 0.1}s` 
                       }}
                     ></div>
                   ))}
                </div>
             </div>
          </div>
          
          <div className="flex flex-col items-center gap-2">
            <div className="flex items-center gap-3">
              <span className="w-2 h-2 bg-red-600 rounded-full animate-pulse"></span>
              <span className="text-[10px] font-black text-stone-900 dark:text-stone-100 uppercase tracking-[0.4em]">Live Neural Link</span>
            </div>
          </div>
        </div>
      )}

      {isSpeaking && !isListening && (
        <div className="flex items-center justify-between px-8 py-5 bg-stone-900 dark:bg-stone-800 text-white dark:text-stone-100 rounded-[32px] shadow-2xl mb-8 animate-in slide-in-from-bottom-8 duration-700 border border-transparent dark:border-stone-700 transition-colors">
          <div className="flex items-center gap-6">
            <div className="relative">
              <div className="absolute inset-0 bg-lime-400 rounded-full animate-ping opacity-20"></div>
              <div className="w-14 h-14 bg-white/10 dark:bg-white/5 border border-white/20 dark:border-white/10 rounded-[24px] flex items-center justify-center relative backdrop-blur-md">
                 <svg className="w-7 h-7 text-lime-400" fill="currentColor" viewBox="0 0 24 24"><path d="M12 3v18c-4.97 0-9-4.03-9-9s4.03-9 9-9z" /></svg>
              </div>
            </div>
            <div className="flex flex-col">
              <span className="text-[10px] font-black text-stone-400 dark:text-stone-500 uppercase tracking-widest">Generating Audio</span>
              <span className="text-sm font-bold tracking-tight">Vocal Response in Progress</span>
            </div>
          </div>
          <button 
            onClick={onStopSpeak}
            className="px-6 py-2.5 bg-lime-600 dark:bg-lime-700 hover:bg-lime-700 dark:hover:bg-lime-600 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all shadow-lg active:scale-95"
          >
            Mute
          </button>
        </div>
      )}

      <form onSubmit={handleSubmit} className="flex items-center gap-4 relative">
        <input 
          type="file" 
          accept="image/*" 
          ref={fileInputRef} 
          className="hidden" 
          onChange={handleFileChange}
        />
        
        <button 
          type="button"
          onClick={() => fileInputRef.current?.click()}
          disabled={isListening || isProcessing}
          className="w-16 h-16 bg-stone-50 dark:bg-stone-800 text-stone-400 dark:text-stone-500 hover:text-stone-900 dark:hover:text-stone-100 hover:bg-stone-100 dark:hover:bg-stone-700 rounded-[24px] transition-all disabled:opacity-50 flex items-center justify-center flex-shrink-0 border border-stone-200 dark:border-stone-700 shadow-sm"
          title="Attach Context"
        >
          <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
          </svg>
        </button>

        <div className="relative flex-1">
          <input 
            type="text"
            value={text}
            onChange={(e) => setText(e.target.value)}
            disabled={isListening || isProcessing}
            placeholder={
              isListening ? "Listening..." : "Submit instant query..."
            }
            className="w-full pl-8 pr-16 py-6 bg-stone-50 dark:bg-stone-800 border-stone-200 dark:border-stone-700 border rounded-[28px] focus:bg-white dark:focus:bg-stone-900 focus:border-lime-500/50 dark:focus:border-lime-500/30 dark:text-stone-100 focus:ring-8 focus:ring-lime-500/5 transition-all outline-none text-stone-900 font-medium placeholder:text-stone-400 dark:placeholder:text-stone-600 shadow-inner text-base"
          />
          <button 
            type="submit"
            disabled={!text.trim() || isListening || isProcessing}
            className="absolute right-3 top-1/2 -translate-y-1/2 p-3.5 text-white dark:text-stone-900 rounded-2xl transition-all shadow-xl bg-stone-900 dark:bg-stone-100 hover:bg-black dark:hover:bg-white disabled:bg-stone-200 dark:disabled:bg-stone-800 disabled:text-stone-400 dark:disabled:text-stone-700"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M13 5l7 7-7 7M5 5l7 7-7 7" /></svg>
          </button>
        </div>

        <button 
          type="button"
          onClick={onToggleListen}
          disabled={isProcessing}
          className={`relative w-20 h-20 rounded-[32px] transition-all active:scale-90 flex items-center justify-center flex-shrink-0 shadow-2xl ${
            isListening 
              ? 'bg-red-700 dark:bg-red-600 text-white shadow-red-500/40 dark:shadow-red-900/40' 
              : 'bg-lime-500 dark:bg-lime-600 text-white shadow-lime-500/40 dark:shadow-lime-900/40 hover:bg-lime-600 dark:hover:bg-lime-500 disabled:opacity-50'
          }`}
        >
          {isListening ? (
             <svg className="w-10 h-10" fill="currentColor" viewBox="0 0 24 24"><path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z" /></svg>
          ) : (
            <svg className="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
            </svg>
          )}
          {isListening && <span className="absolute inset-0 rounded-[32px] bg-red-700 dark:bg-red-600 animate-ping opacity-25"></span>}
        </button>
      </form>
    </div>
  );
};

export default VoiceControls;
