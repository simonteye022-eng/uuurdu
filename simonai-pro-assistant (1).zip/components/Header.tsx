import React, { useState } from 'react';

interface HeaderProps {
  onOpenSidebar: () => void;
  onNewChat: () => void;
  isDarkMode: boolean;
  onToggleDarkMode: () => void;
  currentMood: string;
  onMoodChange: (mood: string) => void;
}

const MOODS = [
  { id: 'mood-neural', color: '#84cc16', name: 'Neural (Lime)' },
  { id: 'mood-ocean', color: '#3b82f6', name: 'Ocean (Blue)' },
  { id: 'mood-nebula', color: '#a855f7', name: 'Nebula (Purple)' },
  { id: 'mood-solar', color: '#f97316', name: 'Solar (Orange)' },
  { id: 'mood-crimson', color: '#ef4444', name: 'Crimson (Red)' },
  { id: 'mood-cyber', color: '#14b8a6', name: 'Cyber (Teal)' },
  { id: 'mood-neon', color: '#ec4899', name: 'Neon (Pink)' },
  { id: 'mood-forest', color: '#10b981', name: 'Forest (Emerald)' },
];

const Header: React.FC<HeaderProps> = ({ 
  onOpenSidebar, 
  onNewChat, 
  isDarkMode, 
  onToggleDarkMode, 
  currentMood, 
  onMoodChange 
}) => {
  const [isMoodOpen, setIsMoodOpen] = useState(false);

  return (
    <header className="px-6 md:px-8 py-5 flex items-center justify-between bg-white/80 dark:bg-stone-900/80 backdrop-blur-md sticky top-0 z-20 border-b border-stone-100 dark:border-stone-800 transition-colors">
      <div className="flex items-center gap-4">
        <button 
          onClick={onOpenSidebar}
          className="p-3 bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 rounded-2xl text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-100 lg:hidden active:scale-90 transition-all"
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>

        <div className="flex items-center gap-4">
          <div className="relative group">
            <div className="w-12 h-12 bg-stone-900 dark:bg-stone-100 rounded-[18px] flex items-center justify-center shadow-xl transform rotate-3 transition-transform group-hover:rotate-0">
              <svg className="w-7 h-7 text-lime-400 dark:text-lime-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.183.394l-1.154.908a1 1 0 00.32 1.748l1.677.335a2 2 0 011.512 1.512l.335 1.677a1 1 0 001.748.32l.908-1.154a2 2 0 01.394-1.183l.158-.318a2 2 0 01.517-3.86l-.477-2.387a2 2 0 00-.547-1.022l-1.154-.908a1 1 0 00-1.748.32l-.335 1.677a2 2 0 01-1.512 1.512l-1.677.335a1 1 0 00-.32 1.748l1.154.908a2 2 0 011.183.394l.318.158a2 2 0 003.86-.517l.477-2.387a2 2 0 011.022-.547l1.154.908a1 1 0 001.748-.32l.335-1.677a2 2 0 011.512-1.512l1.677-.335a1 1 0 00.32-1.748l-1.154-.908z" />
              </svg>
            </div>
            <div className="absolute -top-1 -right-1 w-4 h-4 bg-lime-500 rounded-full border-2 border-white dark:border-stone-900 shadow-lg animate-pulse"></div>
          </div>
          <div className="hidden sm:block">
            <h1 className="text-xl font-heading font-bold text-stone-900 dark:text-stone-50 leading-none">Simon<span className="text-lime-500">AI</span></h1>
            <p className="text-[8px] font-black text-stone-400 dark:text-stone-500 uppercase tracking-[0.3em] mt-1">Universal Neural Architect</p>
          </div>
        </div>
      </div>

      <div className="flex items-center gap-3">
        {/* Mood Selector */}
        <div className="relative">
          <button 
            onClick={() => setIsMoodOpen(!isMoodOpen)}
            className="p-3 bg-stone-50 dark:bg-stone-800 text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-100 rounded-2xl border border-stone-200 dark:border-stone-700 transition-all active:scale-90 relative"
            title="Color Mood"
          >
             <div className="w-5 h-5 rounded-full border-2 border-current flex items-center justify-center overflow-hidden">
                <div className="w-full h-1/2 bg-lime-500"></div>
                <div className="w-full h-1/2 bg-stone-900 dark:bg-stone-100"></div>
             </div>
          </button>

          {isMoodOpen && (
             <>
              <div className="fixed inset-0 z-10" onClick={() => setIsMoodOpen(false)}></div>
              <div className="absolute top-full right-0 mt-3 p-2 bg-white dark:bg-stone-900 border border-stone-100 dark:border-stone-800 rounded-2xl shadow-2xl z-20 w-48 max-h-[60vh] overflow-y-auto custom-scrollbar flex flex-col gap-1 animate-in fade-in zoom-in-95 duration-200">
                <p className="px-3 py-2 text-[10px] font-black uppercase tracking-widest text-stone-400">Select Mood</p>
                {MOODS.map((mood) => (
                  <button
                    key={mood.id}
                    onClick={() => { onMoodChange(mood.id); setIsMoodOpen(false); }}
                    className={`flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all ${
                      currentMood === mood.id 
                        ? 'bg-stone-100 dark:bg-stone-800' 
                        : 'hover:bg-stone-50 dark:hover:bg-stone-800/50'
                    }`}
                  >
                    <div 
                      className="w-4 h-4 rounded-full shadow-sm ring-2 ring-white dark:ring-stone-900" 
                      style={{ backgroundColor: mood.color }}
                    ></div>
                    <span className={`text-xs font-bold ${currentMood === mood.id ? 'text-stone-900 dark:text-stone-100' : 'text-stone-500 dark:text-stone-400'}`}>
                      {mood.name}
                    </span>
                    {currentMood === mood.id && (
                      <svg className="w-3 h-3 ml-auto text-stone-900 dark:text-stone-100" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" /></svg>
                    )}
                  </button>
                ))}
              </div>
             </>
          )}
        </div>

        <button 
          onClick={onToggleDarkMode}
          className="p-3 bg-stone-50 dark:bg-stone-800 text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-100 rounded-2xl border border-stone-200 dark:border-stone-700 transition-all active:scale-90"
          title={isDarkMode ? "Light Mode" : "Dark Mode"}
        >
          {isDarkMode ? (
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z" /></svg>
          ) : (
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" /></svg>
          )}
        </button>

        <button 
          onClick={onNewChat}
          className="hidden md:flex items-center gap-2 px-5 py-2.5 bg-stone-900 dark:bg-stone-100 hover:bg-black dark:hover:bg-white text-white dark:text-stone-900 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all active:scale-95 shadow-lg shadow-stone-900/10 dark:shadow-none"
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M12 6v6m0 0v6m0-6h6m-6 0H6" /></svg>
          New Text
        </button>
        <div className="w-10 h-10 rounded-2xl bg-lime-50 dark:bg-lime-900/20 border border-lime-100 dark:border-lime-700/30 flex items-center justify-center">
          <span className="text-xs font-black text-lime-600 dark:text-lime-400">PRO</span>
        </div>
      </div>
    </header>
  );
};

export default Header;